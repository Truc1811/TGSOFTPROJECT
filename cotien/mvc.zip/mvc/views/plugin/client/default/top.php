<div class="fs-5 fw-bold px-2">
    
</div>
<div class="d-flex px-2">
    <!-- <input class="btn btn-danger me-3" type="submit" value="Delete" name="bn" />
    <input class="btn btn-primary" type="button" value="Add" 
    onclick="window.location.href='admin/add/<?php echo $db; ?>'"  
    />
-->
</div>