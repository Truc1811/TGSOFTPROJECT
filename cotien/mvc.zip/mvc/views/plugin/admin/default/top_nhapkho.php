<div class="fs-5 fw-bold px-2">
    <?php echo $title_name; ?>
</div>
<div class="d-flex px-2">
    <input class="btn btn-primary" type="button" value="Nhập/Xuất kho" 
    onclick="window.location.href='admin/add/<?php echo $db; ?>'" 
    />
</div>