<div class="" style="background-image:url(public/upload/<?php echo $value->image; ?>); background-size: contain; background-position: center center; background-repeat: no-repeat; height:40px">
                                    
</div>