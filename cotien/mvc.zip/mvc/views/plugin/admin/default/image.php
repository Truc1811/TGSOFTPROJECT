<div class="" style="background-image:url(public/upload/<?php echo $value->image; ?>); background-size: cover; height:40px">
                                    
</div>