<div class="col-md-12 mb-3 d-flex flex-wrap">
    <?php
        $thuoctinh=json_decode($data['thuoctinh']);
        $nhomthuoctinh=json_decode($data['nhomthuoctinh']);
        foreach ($nhomthuoctinh as $key => $val) {
    ?>
    <div class="col-6 col-md-3 pe-4 mb-3">
        <label for="input07" class="form-label"><?php echo $val->name; ?></label>
        <?php 
            foreach ($thuoctinh as $key => $value) {
                if($value->nhomthuoctinh==$val->id){
        ?>
            <div class="form-check py-1">
              <input class="form-check-input" type="checkbox" value="<?php echo $value->id; ?>" id="<?php echo 'm'.$value->id; ?>" name="thuoctinh[]">
              <label class="form-check-label" for="<?php echo 'm'.$value->id; ?>">
                <?php if(strlen($value->image)>9){ ?>
                <img style="width:30px" src="public/upload/<?php echo $value->image; ?>">
                <?php } 
                    else { 
                        echo $value->name;
                    } 
                 ?>
              </label>
            </div>
        <?php
                }
            }
        ?>   

            
    </div>
    <?php  
        }
    ?>

</div>