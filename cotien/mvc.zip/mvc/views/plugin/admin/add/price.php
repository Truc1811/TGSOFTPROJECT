<div class="col-12 col-md-6 pe-0 pe-md-4 mb-3">
    <label for="inputEmail9" class="form-label" >Giá bán </label>
    <input type="text" name="price" class="form-control" id="inputEmail9">
</div>
<div class="col-12 col-md-6 pe-0 pe-md-4 mb-3">
    <label for="inputEmail5" class="form-label" >Giá khuyến mãi</label>
    <input type="text" name="discount" class="form-control" id="inputEmail5">
</div>