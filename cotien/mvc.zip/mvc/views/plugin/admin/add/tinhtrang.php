<div class="col-12 col-md-6 pe-0 pe-md-4 mb-3">
    <label for="tinh_trang" class="form-label" >Tình trạng</label>
    <input type="text" name="tinh_trang" class="form-control" id="tinh_trang">
</div>
<div class="col-12 col-md-6 pe-0 pe-md-4 mb-3">
    <label for="sl" class="form-label">Số lượng</label>
    <input type="number" name="soluong" class="form-control" value="1" id="sl">
</div>
<div class="col-12 col-md-6 pe-0 pe-md-4 mb-3">
    <label for="th" class="form-label">Thương hiệu</label>
    <input type="text" name="thuonghieu" class="form-control"  id="th">
</div>
