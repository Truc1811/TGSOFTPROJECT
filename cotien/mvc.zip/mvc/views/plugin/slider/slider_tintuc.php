<style>

    
    
    
    @media (min-width: 768px){
    
    
    @media (min-width: 1400px){
          
}
</style>
<div class="hu_hv p-0">
    <div class="tintuc owl-carousel owl-theme">
    
        <div class="item">
            <div class="card border-0">
                <div>
                    <img class="w-100 rounded-3" src="public/demo/01-03-31-03-thang-an-dam-ridielac-va-gerber-dong-THUMB (1)638778878979643168.png" alt="">
                </div>
                <div class="card-body">
                    <div class="chu-dam">(01/03 - 31/03) Tháng ăn dặm Ridielac và Gerber ĐỒNG GIẢM SỐC 15%. Chốt đơn liền tay mẹ ơi!</div>
                </div>
            </div>
        </div>
        <div class="item">
            <div class="card border-0">
                <div>
                    <img class="w-100 rounded-3" src="public/demo/01-03-31-03-thang-an-dam-ridielac-va-gerber-dong-THUMB (1)638778878979643168.png" alt="">
                </div>
                <div class="card-body">
                    <div class="chu-dam">(01/03 - 31/03) Tháng ăn dặm Ridielac và Gerber ĐỒNG GIẢM SỐC 15%. Chốt đơn liền tay mẹ ơi!</div>
                </div>
            </div>
        </div>
        <div class="item">
            <div class="card border-0">
                <div>
                    <img class="w-100 rounded-3" src="public/demo/01-03-31-03-thang-an-dam-ridielac-va-gerber-dong-THUMB (1)638778878979643168.png" alt="">
                </div>
                <div class="card-body">
                    <div class="chu-dam">(01/03 - 31/03) Tháng ăn dặm Ridielac và Gerber ĐỒNG GIẢM SỐC 15%. Chốt đơn liền tay mẹ ơi!</div>
                </div>
            </div>
        </div>
</div>   
</div>

   


<script src="owlcarousel/owl.carousel.min.js"></script>
<script type="text/javascript">
    $(document).ready(function(){

        $('.tintuc').owlCarousel({
            center: false,
            loop:false,
            margin:20,
            nav:false,
            dots:false,
            autoplay:false,
            responsive:{
                0:{
                    items:1
                },
                600:{
                    items:3
                }
            }
        });
        


    });
</script>