<style>

    
    
    
    @media (min-width: 768px){
    
    
    @media (min-width: 1400px){
            
}
</style>
<div class="hu_hv p-0">
    <div class="qcsua owl-carousel owl-theme">
    
        <div class="item">
            <div>
                <img class="w-100" src="public/demo/sua1.png">
            </div>
        </div>
        <div class="item">
            <div>
                <img class="w-100" src="public/demo/sua2.png" alt="">
            </div>
        </div>
        <div class="item">
            <div>
                <img class="w-100" src="public/demo/sua3.png">
            </div>
        </div>
        <div class="item">
            <div>
                <img class="w-100" src="public/demo/sua4.png">
            </div>
        </div>
        <div class="item">
            <div>
                <img class="w-100" src="public/demo/sua5.png">
            </div>
        </div>
        <div class="item">
            <div>
                <img class="w-100" src="public/demo/sua6.png">
            </div>
        </div>
</div>   
</div>

   


<script src="owlcarousel/owl.carousel.min.js"></script>
<script type="text/javascript">
    $(document).ready(function(){

        $('.qcsua').owlCarousel({
            center: false,
            loop:false,
            margin:0,
            nav:false,
            dots:false,
            autoplay:false,
            responsive:{
                0:{
                    items:1
                },
                600:{
                    items:1
                }
            }
        });
        // $( ".moi4 .owl-next").html('<i class="bi bi-arrow-left-short fs-1"></i>');
        //  $( ".moi4 .owl-prev").html('<i class="bi bi-arrow-right-short fs-1"></i>');


    });
</script>