<style>

    
    @media(min-width: 768px){
       .nesh{
            height: 18vw;
        } 
    }
    
    
</style>
<div class="hu_hv p-0">
    <div class="nes owl-carousel owl-theme">
    
        <div class="item text-center">
            <div class="pb-3">
                <img class="w-100 nesh" src="public/demo/2025_04_04_FarSector_BlogRoll_Mobile_4x3.avif">
            </div>
            <h6 class="text-uppercase">
                weekend escape
            </h6>
            <h4 class="chu-dam text-uppercase">
                jo mullein show us true heroics and strength in far sector
            </h4>
        </div>
        <div class="item text-center">
            <div class="pb-3">
                <img class="w-100 nesh" src="public/demo/2025_04_02_AbsoluteGreenLantern_BlogRoll_Mobile_4x3.avif" alt="">
            </div>
            <h6 class="text-uppercase">
                weekend escape
            </h6>
            <h4 class="chu-dam text-uppercase">
                jo mullein show us true heroics and strength in far sector
            </h4>
        </div>
        <div class="item text-center">
            <div class="pb-3">
                <img class="w-100 nesh" src="public/demo/2025_04_03_SupermanLuthor_BlogRoll_Mobile_4x3.avif">
            </div>
            <h6 class="text-uppercase">
                weekend escape
            </h6>
            <h4 class="chu-dam text-uppercase">
                jo mullein show us true heroics and strength in far sector
            </h4>
        </div>
        
        
    </div>   
</div>

   


<script src="owlcarousel/owl.carousel.min.js"></script>
<script type="text/javascript">
    $(document).ready(function(){

        $('.nes').owlCarousel({
            center: false,
            loop:false,
            margin:20,
            nav:false,
            dots:false,
            autoplay:false,
            responsive:{
                0:{
                    items:1
                },
                600:{
                    items:3
                }
            }
        });
        // $( ".nes .owl-next").html('<i class="bi bi-arrow-left-short fs-1"></i>');
        //  $( ".nes .owl-prev").html('<i class="bi bi-arrow-right-short fs-1"></i>');


    });
</script>