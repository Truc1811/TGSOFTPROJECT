<style>

    
    
    
    @media (min-width: 768px){
    
    
    @media (min-width: 1400px){
          
}
</style>
<div class="hu_hv p-0">
    <div class="moi4 owl-carousel owl-theme">
    
        <div class="item">
            <div>
                <img class="w-100 rounded" src="public/demo/5d7ba5cfee0a5fed643292e52422d660.png" alt="">
            </div>
        </div>
        <div class="item">
            <div>
                <img class="w-100 rounded" src="public/demo/1b003c3c727b6073e264cb9fb4ecf0ad.png" alt="">
            </div>
        </div>
        <div class="item">
            <div>
                <img class="w-100 rounded" src="public/demo/9bea9e3bf1811887dda342c2cb5c9aed.jpg" alt="">
            </div>
        </div>
        <div class="item">
            <div>
                <img class="w-100 rounded" src="public/demo/cf2e26d270f4ff75381acaf97d9fa528.png" alt="">
            </div>
        </div>
</div>   
</div>

   


<script src="owlcarousel/owl.carousel.min.js"></script>
<script type="text/javascript">
    $(document).ready(function(){

        $('.moi4').owlCarousel({
            center: false,
            loop:false,
            margin:20,
            nav:false,
            dots:false,
            autoplay:false,
            responsive:{
                0:{
                    items:1
                },
                600:{
                    items:3
                }
            }
        });
        


    });
</script>