<style>

    
    .theicdd{
        border-radius: 1.5vw;
        border: 1px solid #dedede;
    }
    
    @media (min-width: 768px){
    
    
    @media (min-width: 1400px){
         
}
</style>
<div class="hu_hv p-0">
    <div class="tc1 owl-carousel owl-theme">
    
        <div class="item">
            <div class="d-flex align-items-center theicdd p-3">
                <div class="pe-3">
                    <img class="ic" src="public/demo/09b47cbabe5dee4234f52c6ca40ad73f.png" alt="">
                </div>
                <h5>
                    Deal ngon Online
                </h5>
            </div>
        </div>
        <div class="item">
            <div class="d-flex align-items-center theicdd p-3">
                <div class="pe-3">
                    <img class="ic" src="public/demo/85bbd6427d4d7dfd311360cb50cc04ea.png" alt="">
                </div>
                <h5>
                    Giảm đến 50%
                </h5>
            </div>
        </div>
        <div class="item">
            <div class="d-flex align-items-center theicdd p-3">
                <div class="pe-3">
                    <img class="ic" src="public/demo/a654150d5b64207705d1bb51b6aa8d57.png" alt="">
                </div>
                <h5>
                    Ưu đãi tháng 3
                </h5>
            </div>
        </div>
        <div class="item">
            <div class="d-flex align-items-center theicdd p-3">
                <div class="pe-3">
                    <img class="ic" src="public/demo/9eeb1e459af47d94e332da8e5a6999d0.png" alt="">
                </div>
                <h5>
                    Ăn dặm Ridielac & Gerber
                </h5>
            </div>
        </div>
</div>   
</div>

   


<script src="owlcarousel/owl.carousel.min.js"></script>
<script type="text/javascript">
    $(document).ready(function(){

        $('.tc1').owlCarousel({
            center: false,
            loop:false,
            margin:0,
            nav:false,
            dots:false,
            autoplay:false,
            responsive:{
                0:{
                    items:1
                },
                600:{
                    items:2
                }
            }
        });
        


    });
</script>