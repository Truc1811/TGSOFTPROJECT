<div class="display_flex_column_m_1 padding_3 font_ct">
<div style="padding: 5vw 0 5vw 0;" class="font_ct">

Nội dung này chỉ dành cho học viên. Bạn vui lòng đăng nhập để truy cập.<br/>
<a href="hoc-vien/quanly">
	Đăng nhập
</a>
</div>
</div>
<div class="display_flex_column_m_1 font_ct color_trang padding_3">
            <?php require_once "mvc/views/theme/gd000001/cotphai.php"; ?>
</div>