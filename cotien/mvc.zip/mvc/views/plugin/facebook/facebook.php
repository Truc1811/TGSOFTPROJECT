<!--nhúng face book-->
<div id="fb-root"></div>
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/vi_VN/sdk.js#xfbml=1&version=v12.0" nonce="hUli5bN0"></script>
<!--end code nhúng face book-->

<!--
data-width="1000px"  //max-width của plugin  - plugin tự fit với khung chứa khi width nhỏ hơn data-width
data-height="180px"  // chiều cao plugin
-->


<!-- <div class="fb-page" data-href="https://www.facebook.com/vlsv.vltd.ldpt" data-tabs="timeline" data-width="100%" data-height="120px" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true" style="width: 100% !important;">
	<blockquote cite="https://www.facebook.com/vlsv.vltd.ldpt" class="fb-xfbml-parse-ignore">
		<a href="https://www.facebook.com/vlsv.vltd.ldpt"  target="_top">
			Jobopen.vn
		</a>
	</blockquote>
</div> -->
<div class="fb-page fb_iframe_widget" data-href="<?php echo $cauhinh[0]->facebook; ?>" data-tabs="timeline" data-width="" data-height="120" data-small-header="false" data-adapt-container-width="false" data-hide-cover="false" data-show-facepile="true" fb-xfbml-state="rendered" fb-iframe-plugin-query="adapt_container_width=false&amp;app_id=&amp;container_width=242&amp;height=120&amp;hide_cover=false&amp;href=https://www.facebook.com/vlsv.vltd.ldpt&amp;locale=vi_VN&amp;sdk=joey&amp;show_facepile=true&amp;small_header=false&amp;tabs=timeline&amp;width="><span style="vertical-align: bottom; width: 400px; height: 250px;"><iframe name="fee9f81192b8e4" width="1000px" height="120px" data-testid="fb:page Facebook Social Plugin" title="fb:page Facebook Social Plugin" frameborder="0" allowtransparency="true" allowfullscreen="true" scrolling="no" allow="encrypted-media" src="https://www.facebook.com/v3.3/plugins/page.php?adapt_container_width=false&amp;app_id=&amp;channel=https%3A%2F%2Fstaticxx.facebook.com%2Fx%2Fconnect%2Fxd_arbiter%2F%3Fversion%3D46%23cb%3Df3fd80e46169678%26domain%3Dtgsoft.vn%26is_canvas%3Dfalse%26origin%3Dhttps%253A%252F%252Ftgsoft.vn%252Ff39f8a93b517c7c%26relation%3Dparent.parent&amp;container_width=242&amp;height=120&amp;hide_cover=false&amp;href=https%3A%2F%2Fwww.facebook.com%2Fcongtytgsoft%2F&amp;locale=vi_VN&amp;sdk=joey&amp;show_facepile=true&amp;small_header=false&amp;tabs=timeline&amp;width=" style="border: none; visibility: visible; width: 400px; height: 250px;" class=""></iframe></span></div>