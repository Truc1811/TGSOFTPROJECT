<!--
data-width="1000px"  //max-width của plugin  - plugin tự fit với khung chứa khi width nhỏ hơn data-width
data-height="180px"  // chiều cao plugin
-->


<div class="fb-page" data-href="https://www.facebook.com/kienthucblockchain2022/" data-tabs="timeline" data-width="1000px" data-height="180px" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true" style="width: 100% !important;">
	<blockquote cite="https://www.facebook.com/kienthucblockchain2022/" class="fb-xfbml-parse-ignore">
		<a href="https://www.facebook.com/kienthucblockchain2022/">
			KienthucBlockchain.net
		</a>
	</blockquote>
</div>