<div class="container-fluid bg-black overflow-hidden" style="position:fixed; height:100vh; z-index:9999; top:0px; left:0px">
	<div class="row bg-black d-flex justify-content-center align-items-center h-100">
		<div class="col-12 col-md-2 col-xl-1">
			<img class="w-100" src="public/upload/<?php echo $cauhinh[0]->logo; ?>">
		</div>

	</div>

</div>