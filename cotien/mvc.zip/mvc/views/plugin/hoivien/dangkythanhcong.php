<style type="text/css">
	.header-top{
		background-color: var(--header-top);
	}
	@media(min-width: 768px){
		.header-top{
			background-color: var(--header-top);
		}
	}
	@media(min-width: 1400px){
		.header-top{
			background-color: var(--header-top);
		}
	}
</style>
<div class="row justify-content-center">
	<div class="col-6">
		<div class="bg-white p-3 shadow">
			<img class="w-100" src="public/demo/success.jpg" alt="">
		</div>
		<div>
			<div>
				<button class="btn header-top" data-bs-toggle="modal" data-bs-target="#exampleModal">
					Chuyển sang trang đăng nhập
				</button>
			</div>
		</div>
	</div>
</div>