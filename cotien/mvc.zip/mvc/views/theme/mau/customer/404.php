<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Khung Sản Phẩm Giao Diện App</title>
  
</head>
<body>

<div class="container py-3">

  <!-- Dòng sản phẩm -->
  <div class="row g-3">
    <!-- SP 1 -->
    <div class="col-md-12">
        <img src="https://static.vecteezy.com/system/resources/previews/006/549/647/non_2x/404-landing-page-free-vector.jpg" alt="" class="w-100 img-fluid">
    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
