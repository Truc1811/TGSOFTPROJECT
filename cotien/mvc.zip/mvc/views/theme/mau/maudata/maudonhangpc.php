<style>
    .status-badge {
        font-size: 0.8rem;
        padding: 4px 8px;
        border-radius: 12px;
    }

    .overlay {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: black;
        opacity: 0.4;
        z-index: 999;
        display: none;
    }

    .chitietdonhangpc {
        position: fixed;
        width: 100%;
        max-width: 600px;
        left: 50%;
        top: 50%;
        transform: translate(-50%, -50%) scale(0.95);
        opacity: 0;
        visibility: hidden;
        background-color: transparent;
        box-shadow: none;
        z-index: 1050;
        transition: all 0.4s ease;
        max-height: 90vh;
        overflow-y: auto;
        overflow-x: hidden;
        padding: 0;
        margin-top: 0;
    }

    .showchitietdonhangpc {
        opacity: 1;
        visibility: visible;
        transform: translate(-50%, -50%) scale(1);
    }
</style>

<?php

// Dữ liệu đơn hàng mẫu
$mang_listdonhang2 = json_decode($data['order']);

?>

<!-- Giao diện danh sách đơn -->
<div class="input-group p-3">
    <input type="text" class="form-control" placeholder="Nhập tên, số điện thoại, mã">
    <button class="btn btn-outline-secondary" type="button"><i class="bi bi-upc-scan"></i></button>
</div>

<div class="row">
    <?php foreach ($mang_listdonhang2 as $valldh2): ?>
        <div class="col-md-3 mb-3">
            <div class="order-card bg-light rounded-2 mb-3 donhangpc p-3 h-100 shadow-sm">
                <div class="d-flex justify-content-between align-items-center m-2">
                    <h5 class="fw-bold text-primary"><?php echo $valldh2->order_id ?></h5>
                    <?php
                    $statusText = '';
                    $statusClass = '';

                    switch ($valldh2->svdt_status) {
                        case 1:
                            $statusText = 'Đã đặt';
                            $statusClass = 'status-badge bg-warning text-dark';
                            break;
                        case 2:
                            $statusText = 'Đã xác nhận';
                            $statusClass = 'status-badge bg-primary text-white';
                            break;
                        case 3:
                            $statusText = 'Đã hoàn thành';
                            $statusClass = 'status-badge bg-success text-white';
                            break;
                        case 4:
                            $statusText = 'Đã hủy';
                            $statusClass = 'status-badge bg-danger text-white';
                            break;
                        default:
                            $statusText = 'Không xác định';
                            $statusClass = 'status-badge bg-secondary text-white';
                            break;
                    }

                    echo "<span class='$statusClass'>$statusText</span>";
                    ?>
                </div>

                <div class="m-2 cursor">
                    <h5 class="text-danger mt-2"><?php echo number_format($valldh2->oddt_price, 0, ',', ',') ?></h5>
                    <p class="mb-1 fw-bold"><i class="bi bi-person"></i> <?php echo $valldh2->cus_name ?> - <?php echo $valldh2->cus_phone ?></p>
                    <p class="mb-1 text-black-50">Địa chỉ:&ensp;<?php echo $valldh2->cus_address ?></p>
                    <p class="mb-1 text-black-50">Khách sạn:<?php echo $valldh2->sv_name ?></p>
                </div>
            </div>

            <!-- Chi tiết đơn -->
            <div class="container-fluid chitietdonhangpc show_don_hang bg-light">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="d-flex justify-content-between bg-primary text-white p-3">
                                <h5 class="mb-0">Đơn đặt phòng</h5>
                                <div class="dong" title="Quay lại" style="cursor: pointer;">
                                    <i class="bi bi-arrow-left fs-5"></i>
                                </div>
                            </div>
                            <div class="card-body text-black-50">
                                <h6 class="mb-3">🏨 Thông tin đặt phòng khách sạn</h6>
                                <ul class="list-group list-group-flush mb-4">
                                    <li class="list-group-item">Khách sạn: <?php echo $valldh2->sv_name ?></li>
                                    <li class="list-group-item">Loại phòng: <?php echo $valldh2->svdt_name ?></li>
                                    <li class="list-group-item text-danger">Giá phòng: <?php echo number_format($valldh2->oddt_price, 0, ',', ',') ?></li>
                                </ul>
                                <h6 class="mb-3">👤 Thông tin khách hàng</h6>
                                <ul class="list-group list-group-flush">
                                    <li class="list-group-item">Họ và tên: <?php echo $valldh2->cus_name ?></li>
                                    <li class="list-group-item">Số điện thoại: <?php echo $valldh2->cus_phone ?></li>
                                    <li class="list-group-item">Email: <?php echo $valldh2->cus_email ?></li>
                                    <li class="list-group-item">Ghi chú: Yêu cầu phòng tầng cao, không hút thuốc</li>
                                </ul>
                            </div>
                        </div>
                        <div class="m-3 d-flex justify-content-between">
                            <label>
                                <input type="checkbox" name="status" value="1" <?= ($valldh2->svdt_status == 1) ? 'checked' : '' ?>> Đã đặt
                            </label><br>

                            <label>
                                <input type="checkbox" name="status" value="2" <?= ($valldh2->svdt_status == 2) ? 'checked' : '' ?>> Đã xác nhận
                            </label><br>

                            <label>
                                <input type="checkbox" name="status" value="3" <?= ($valldh2->svdt_status == 3) ? 'checked' : '' ?>> Đã hoàn thành
                            </label><br>

                            <label>
                                <input type="checkbox" name="status" value="4" <?= ($valldh2->svdt_status == 4) ? 'checked' : '' ?>> Đã hủy
                            </label>


                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<div class="overlay"></div>

<script>
    $(document).ready(function() {
        $('.donhangpc').click(function() {
            $(this).next().addClass('showchitietdonhangpc');
            $('.overlay').show();
        });

        $('.dong').click(function() {
            $('.chitietdonhangpc').removeClass('showchitietdonhangpc');
            $('.overlay').hide();
        });
    });
</script>