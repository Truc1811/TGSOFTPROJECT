<div class="my-3">
  <div class="card shadow">
    <img src="https://q-xx.bstatic.com/xdata/images/hotel/263x210/595550862.jpeg?k=3514aa4abb76a6d19df104cb307b78b841ac0676967f24f4b860d289d55d3964&o=" class="card-img-top" alt="Hình ảnh căn hộ">
    <div class="card-body">
      <h3 class="card-title">Khách Sạn</h3>
      <p class="card-text">Thiết kế sang xịn và kiến trúc đẹp của kỹ sư người Pháp.</p>

      <ul class="list-group list-group-flush my-3">
        <li class="list-group-item"><strong>Tình trạng:</strong> <span class="text-danger">Đã cho thuê</span></li>
        <li class="list-group-item"><strong>Số người ở:</strong> 2 người</li>
        <li class="list-group-item"><strong>Giá thuê:</strong> <span class="text-danger fw-bold">5,000,000 VND / Tháng</span></li>
      </ul>
    </div>
  </div>
</div>