<style type="text/css">
    .tag_click:hover{
        background-color: #0B5ED7;
    }
</style>



<!----start---->
<div class="d-none d-md-block col-2 bg_colleft p-0 overflow-auto scrollbar" style="height:98vh;">

    <div class="tag_click d-flex p-6 border-bottom border-secondary text-white cursor" onclick="window.location.href='admin/tongquan'">
        <div class="d-flex align-items-center px-2 py-3">
           <i class="bi bi-border-all"></i>            
       </div>
       <div class="d-flex align-items-center px-2 py-3">
        Tổng quan
    </div>               
</div>
<div class="tag_click d-flex p-6 border-bottom border-secondary text-white cursor" onclick="window.location.href='admin/update/configuration/1/1'">
    <div class="d-flex align-items-center px-2 py-3">
        <i class="bi bi-gear-wide-connected"></i>             
    </div>
    <div class="d-flex align-items-center px-2 py-3">
       Trang chủ        
   </div>               
</div>
<div class="tag_click d-flex p-6 border-bottom border-secondary text-white cursor" onclick="window.location.href='admin/listr/blog'">
    <div class="d-flex align-items-center px-2 py-3">
       <i class="bi bi-substack"></i>              
   </div>
   <div class="d-flex align-items-center px-2 py-3">
    Blog
</div>               
</div> 
<div class="tag_click d-flex p-6 border-bottom border-secondary text-white cursor" onclick="window.location.href='admin/listr/faqs'">
    <div class="d-flex align-items-center px-2 py-3">
       <i class="bi bi-question-circle-fill"></i>            
   </div>
   <div class="d-flex align-items-center px-2 py-3">
    FAQS
</div>               
</div>
<div class="tag_click d-flex p-6 border-bottom border-secondary text-white cursor" onclick="window.location.href='admin/listr/khachhang'">
    <div class="d-flex align-items-center px-2 py-3">
       <i class="bi bi-people-fill"></i>            
   </div>
   <div class="d-flex align-items-center px-2 py-3">
    Khách hàng
</div>               
</div> 
<div class="tag_click d-flex p-6 border-bottom border-secondary text-white cursor" onclick="window.location.href='admin/listr/user'">
    <div class="d-flex align-items-center px-2 py-3">
       <i class="bi bi-people-fill"></i>            
   </div>
   <div class="d-flex align-items-center px-2 py-3">
    User
</div>               
</div>
<div class="tag_click d-flex p-6 border-bottom border-secondary text-white cursor" onclick="window.location.href='admin/listr/thongtintaisan'">
    <div class="d-flex align-items-center px-2 py-3">
        <i class="bi bi-info-circle-fill"></i>           
    </div>
    <div class="d-flex align-items-center px-2 py-3">
        Thông tin tài sản
    </div>               
</div>


 <!--    <div class="tag_click d-flex p-6 border-bottom border-secondary text-white cursor" onclick="window.location.href='admin/listr/kho'">
        <div class="d-flex align-items-center px-2 py-3">
            <i class="bi bi-bag-fill"></i>              
        </div>
        <div class="d-flex align-items-center px-2 py-3">
            Kho
        </div>               
    </div>
    <div class="tag_click d-flex p-6 border-bottom border-secondary text-white cursor" onclick="window.location.href='admin/listr/khachhang'">
        <div class="d-flex align-items-center px-2 py-3">
            <i class="bi bi-bag-fill"></i>              
        </div>
        <div class="d-flex align-items-center px-2 py-3">
            Khách hàng
        </div>               
    </div>

    <div class="tag_click d-flex p-6 border-bottom border-secondary text-white cursor" onclick="window.location.href='admin/listr/hoadon'">
        <div class="d-flex align-items-center px-2 py-3">
            <i class="bi bi-newspaper"></i>              
        </div>
        <div class="d-flex align-items-center px-2 py-3">
            Hóa đơn 
        </div>               
    </div>  -->
    

    

   <!--  <div class="tag_click d-flex p-6 border-bottom border-secondary text-white cursor" onclick="window.location.href='admin/listr/menu'">
        <div class="d-flex align-items-center px-2 py-3">
            <i class="bi bi-newspaper"></i>              
        </div>
        <div class="d-flex align-items-center px-2 py-3">
           Menu      
        </div>               
    </div> -->
    

    


 <!-- <div class="tag_click d-flex p-6 border-bottom border-secondary text-white cursor" onclick="window.location.href='admin/add/menu'">
            <div class="d-flex align-items-center px-2 py-3">
                <i class="bi bi-list-nested"></i>              
            </div>
            <div class="d-flex align-items-center px-2 py-3">
                   Danh mục         
            </div>               
        </div> -->
        <!-- <div class="tag_click d-flex p-6 border-bottom border-secondary text-white cursor" onclick="window.location.href='admin/listr/faqs'">
            <div class="d-flex align-items-center px-2 py-3">
                <i class="bi bi-bookmarks-fill"></i>              
            </div>
            <div class="d-flex align-items-center px-2 py-3">
                   FAQS       
            </div>               
        </div> -->
        <!-- <div class="tag_click d-flex p-6 border-bottom border-secondary text-white cursor" onclick="window.location.href='admin/listr/characters'">
            <div class="d-flex align-items-center px-2 py-3">
                <i class="bi bi-bookmarks-fill"></i>              
            </div>
            <div class="d-flex align-items-center px-2 py-3">
               Characters       
           </div>               
       </div> -->
       <!-- <div class="tag_click d-flex p-6 border-bottom border-secondary text-white cursor" onclick="window.location.href='admin/listr/comics'">
        <div class="d-flex align-items-center px-2 py-3">
            <i class="bi bi-house-fill"></i>             
        </div>
        <div class="d-flex align-items-center px-2 py-3">
           Comics         
       </div>               
   </div> -->
   <!-- <div class="tag_click d-flex p-6 border-bottom border-secondary text-white cursor" onclick="window.location.href='admin/listr/games'">
    <div class="d-flex align-items-center px-2 py-3">
        <i class="bi bi-list-nested"></i>            
    </div>
    <div class="d-flex align-items-center px-2 py-3">
       Games       
   </div>               
</div> -->
<!-- <div class="tag_click d-flex p-6 border-bottom border-secondary text-white cursor" onclick="window.location.href='admin/listr/tvshows'">
    <div class="d-flex align-items-center px-2 py-3">
        <i class="bi bi-film"></i>            
    </div>
    <div class="d-flex align-items-center px-2 py-3">
       Video     
   </div>               
</div> -->
<!-- <div class="tag_click d-flex p-6 border-bottom border-secondary text-white cursor" onclick="window.location.href='admin/listr/hopthu'">
    <div class="d-flex align-items-center px-2 py-3">
        <i class="bi bi-box-fill"></i>             
    </div>
    <div class="d-flex align-items-center px-2 py-3">
       Hộp thư        
   </div>               
</div> -->



        <!-- <div class="tag_click d-flex p-6 border-bottom border-secondary text-white cursor" onclick="window.location.href='admin/listr/quangcao'">
            <div class="d-flex align-items-center px-2 py-3">
                <i class="bi bi-person-vcard"></i>             
            </div>
            <div class="d-flex align-items-center px-2 py-3">
                   Quảng cáo         
            </div>               
        </div> -->
        <!-- <div class="tag_click d-flex p-6 border-bottom border-secondary text-white cursor" onclick="window.location.href='admin/listr/donhang'">
            <div class="d-flex align-items-center px-2 py-3">
                <i class="bi bi-palette"></i>             
            </div>
            <div class="d-flex align-items-center px-2 py-3">
                   Đơn hàng         
            </div>               
        </div> -->
       <!--  <div class="tag_click d-flex p-6 border-bottom border-secondary text-white cursor" onclick="window.location.href='admin/listr/sanpham'">
            <div class="d-flex align-items-center px-2 py-3">
                <i class="bi bi-clipboard-check-fill"></i>              
            </div>
            <div class="d-flex align-items-center px-2 py-3">
                   Sản phẩm       
            </div>               
        </div>
        <div class="tag_click d-flex p-6 border-bottom border-secondary text-white cursor" onclick="window.location.href='admin/listr/tintuc'">
            <div class="d-flex align-items-center px-2 py-3">
                <i class="bi bi-newspaper"></i>              
            </div>
            <div class="d-flex align-items-center px-2 py-3">
                Tin tức         
            </div>               
        </div> -->
       <!--  <div class="tag_click d-flex p-6 border-bottom border-secondary text-white cursor" onclick="window.location.href='admin/listr/thuoctinh'">
            <div class="d-flex align-items-center px-2 py-3">
                <i class="bi bi-bookmarks-fill"></i>              
            </div>
            <div class="d-flex align-items-center px-2 py-3">
                Thuộc tính         
            </div>               
        </div> -->
       <!--  <div class="tag_click d-flex p-6 border-bottom border-secondary text-white cursor" onclick="window.location.href='admin/listr/nhomthuoctinh'">
            <div class="d-flex align-items-center px-2 py-3">
                <i class="bi bi-person"></i>              
            </div>
            <div class="d-flex align-items-center px-2 py-3">
                Nhóm thuộc tính  
            </div>               
        </div> -->
        <!-- <div class="tag_click d-flex p-6 border-bottom border-secondary text-white cursor" onclick="window.location.href='admin/listr/hoivien'">
            <div class="d-flex align-items-center px-2 py-3">
                <i class="bi bi-person"></i>              
            </div>
            <div class="d-flex align-items-center px-2 py-3">
               Hội viên 
            </div>               
        </div> -->
        
        
        
    </div>
<!----- end---->