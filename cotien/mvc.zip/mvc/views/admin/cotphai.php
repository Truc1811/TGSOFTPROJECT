<div class="col-12 col-md-10 p-0">
    <?php
        require_once "mvc/views/admin/".json_decode($data['page']).".php";
    ?>
</div>