<?php
class thuvienmkh{
	private $mau='user000005';
	public $map='password000005';
	private $mai='id000005';
	private $mal='l000005';
	private $mauk='userk000005';
	private $mapk='passwordk000005';
	private $maik='idk000005';
	private $matheme='mau';
	
	public function getu(){
		return $this->mau;
	}
	
	public function getp(){		
		return $this->map;
	}
	
	public function geti(){
		return $this->mai;
	}

	public function getl(){
		return $this->mal;
	}
	
	public function getuk(){
		return $this->mauk;
	}
	
	public function getpk(){
		return $this->mapk;
	}
	
	public function getik(){
		return $this->maik;
	}

	public function gettheme(){
		return $this->matheme;
	}
	
}

?>