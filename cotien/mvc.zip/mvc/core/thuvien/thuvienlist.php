<?php
class thuvienlist{
	
	public function in(){
		echo "<script>alert('thanh cong')</script>";
	}
	
}

?>